import { inject, TestBed } from '@angular/core/testing';

import { CalculadoraService } from './calculadora.service';

describe('CalculadoraService', () => {
  let service: CalculadoraService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculadoraService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Deve garantir que 2 + 2 = 4'),
    inject([CalculadoraService], (service: CalculadoraService) => {
    let soma = service.calcular(2,2, CalculadoraService.SOMA);
    expect(soma).toEqual(4);
    })
  
  it('Deve garantir que 2 - 2 = 0'),
    inject([CalculadoraService], (service: CalculadoraService) => {
    let subt = service.calcular(2,2, CalculadoraService.SUBT);
    expect(subt).toEqual(0);
    })

  it('Deve garantir que 2 * 10 = 20'),
    inject([CalculadoraService], (service: CalculadoraService) => {
    let mult = service.calcular(2,10, CalculadoraService.MULT);
    expect(mult).toEqual(20);
    })

  it('Deve garantir que 2 / 2 = 1'),
    inject([CalculadoraService], (service: CalculadoraService) => {
    let div = service.calcular(2,2, CalculadoraService.DIV);
    expect(div).toEqual(1);
    })

});
