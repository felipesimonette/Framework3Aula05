import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculadoraService {

  // Definição das constantes para identificar as operações

  static readonly SOMA: string = "+";
  static readonly SUBT: string = "-";
  static readonly DIV: string = "/";
  static readonly MULT: string = "*";


  constructor() { }

  /**
   * Método utilizado para calcular o valor da operação 
   * @param num1 :Primeiro valor inserido pelo usuário
   * @param num2 :Segundo valor inserido pelo usuário
   * @param operacao :Operação solicitada pelo usuário 
   * @returns :Resultado
   */

  calcular(num1: number, num2: number, operacao: string): number {

    let resultado: number;

    switch (operacao) {
      case CalculadoraService.SOMA:
        resultado = num1 + num2;
        break;
      case CalculadoraService.SUBT:
        resultado = num1 - num2;
        break;
      case CalculadoraService.DIV:
        resultado = num1 / num2;
        break;
      case CalculadoraService.MULT:
        resultado = num1 * num2;
        break;
      default:
        resultado = 0;
    }
    return resultado
  }
}
